package uno;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

@DisplayName("Pruebas de la clase ControlTurnos")
public class ControlTurnosTest {
    
    private ControlTurnos control3Jugadores;
    private ControlTurnos control4Jugadores;
    
    @BeforeEach
    void setUp() {
        control3Jugadores = new ControlTurnos(3);
        control4Jugadores = new ControlTurnos(4);
    }
    
    //PRUEBAS DEL CONSTRUCTOR
    
    @Test
    @DisplayName("Constructor - debe inicializar correctamente con 3 jugadores")
    void testConstructorCon3Jugadores() {
        assertEquals(0, control3Jugadores.getIndiceActual());
        // Verificamos que el siguiente índice sea 1 (dirección positiva)
        assertEquals(1, control3Jugadores.obtenerSiguienteIndice());
    }
    
    @Test 
    @DisplayName("Constructor - debe inicializar correctamente con 4 jugadores")
    void testConstructorCon4Jugadores() {
        assertEquals(0, control4Jugadores.getIndiceActual());
        assertEquals(1, control4Jugadores.obtenerSiguienteIndice());
    }
    
    @Test
    @DisplayName("Constructor - debe funcionar con 1 jugador")
    void testConstructorCon1Jugador() {
        ControlTurnos control1 = new ControlTurnos(1);
        assertEquals(0, control1.getIndiceActual());
        
        control1.avanzar();
        assertEquals(0, control1.getIndiceActual()); // Siempre el mismo
    }
    
    @Test
    @DisplayName("Constructor - debe funcionar con 2 jugadores")
    void testConstructorCon2Jugadores() {
        ControlTurnos control2 = new ControlTurnos(2);
        assertEquals(0, control2.getIndiceActual());
        assertEquals(1, control2.obtenerSiguienteIndice());
    }
    
    //PRUEBAS DE GETTERS
    
    @Test
    @DisplayName("getIndiceActual - debe retornar el índice actual correctamente")
    void testGetIndiceActual() {
        assertEquals(0, control3Jugadores.getIndiceActual());
        
        control3Jugadores.avanzar();
        assertEquals(1, control3Jugadores.getIndiceActual());
        
        control3Jugadores.avanzar();
        assertEquals(2, control3Jugadores.getIndiceActual());
    }
    
    //PRUEBAS DE AVANZAR
    
    @Test
    @DisplayName("avanzar - debe avanzar al siguiente jugador en dirección normal")
    void testAvanzarDireccionNormal() {
        // Jugador 0 -> 1
        control3Jugadores.avanzar();
        assertEquals(1, control3Jugadores.getIndiceActual());
        
        // Jugador 1 -> 2
        control3Jugadores.avanzar();
        assertEquals(2, control3Jugadores.getIndiceActual());
        
        // Jugador 2 -> 0 (vuelta al inicio)
        control3Jugadores.avanzar();
        assertEquals(0, control3Jugadores.getIndiceActual());
    }
    
    @Test
    @DisplayName("avanzar - debe funcionar correctamente en ciclo completo")
    void testAvanzarCicloCompleto() {
        // Para 3 jugadores: 0 -> 1 -> 2 -> 0 -> 1
        int[] esperados = {1, 2, 0, 1};
        
        for (int esperado : esperados) {
            control3Jugadores.avanzar();
            assertEquals(esperado, control3Jugadores.getIndiceActual());
        }
    }
    
    @Test
    @DisplayName("avanzar - con 2 jugadores debe alternar entre 0 y 1")
    void testAvanzarCon2Jugadores() {
        ControlTurnos control2 = new ControlTurnos(2);
        
        assertEquals(0, control2.getIndiceActual());
        control2.avanzar();
        assertEquals(1, control2.getIndiceActual());
        control2.avanzar();
        assertEquals(0, control2.getIndiceActual());
        control2.avanzar();
        assertEquals(1, control2.getIndiceActual());
    }
    
    //PRUEBAS DE CAMBIAR DIRECCIÓN
    
    @Test
    @DisplayName("cambiarDireccion - debe invertir la dirección")
    void testCambiarDireccion() {
        // Dirección normal (1): 0 -> 1
        control3Jugadores.avanzar();
        assertEquals(1, control3Jugadores.getIndiceActual());
        
        // Cambiar dirección a -1
        control3Jugadores.cambiarDireccion();
        
        // Ahora debería retroceder: 1 -> 0
        control3Jugadores.avanzar();
        assertEquals(0, control3Jugadores.getIndiceActual());
        
        // Avanzar de nuevo: 0 -> 2 (porque retrocede: 0 - 1 = -1 + 3 = 2)
        control3Jugadores.avanzar();
        assertEquals(2, control3Jugadores.getIndiceActual());
    }
    
    @Test
    @DisplayName("cambiarDireccion - múltiples cambios debe alternar dirección")
    void testCambiarDireccionMultiple() {
        // Empezamos con dirección 1
        control4Jugadores.avanzar();
        assertEquals(1, control4Jugadores.getIndiceActual());
        
        // Cambiar a -1
        control4Jugadores.cambiarDireccion();
        control4Jugadores.avanzar();
        assertEquals(0, control4Jugadores.getIndiceActual()); // Retrocede: 1 -> 0
        
        // Cambiar a 1 nuevamente
        control4Jugadores.cambiarDireccion();
        control4Jugadores.avanzar();
        assertEquals(1, control4Jugadores.getIndiceActual()); // Avanza: 0 -> 1
    }
    
    @Test
    @DisplayName("cambiarDireccion - debe afectar a obtenerSiguienteIndice")
    void testCambiarDireccionAfectaSiguiente() {
        // Dirección normal: siguiente es 1
        assertEquals(1, control3Jugadores.obtenerSiguienteIndice());
        
        // Cambiar dirección: siguiente debería ser 2 (porque retrocede: 0 - 1 = -1 + 3 = 2)
        control3Jugadores.cambiarDireccion();
        assertEquals(2, control3Jugadores.obtenerSiguienteIndice());
    }
    
    //PRUEBAS DE SALTAR TURNO
    
    @Test
    @DisplayName("saltarTurno - debe saltar al siguiente jugador")
    void testSaltarTurno() {
        // Jugador actual: 0
        control3Jugadores.saltarTurno();
        assertEquals(1, control3Jugadores.getIndiceActual());
        
        control3Jugadores.saltarTurno();
        assertEquals(2, control3Jugadores.getIndiceActual());
    }
    
    @Test
    @DisplayName("saltarTurno - con dirección cambiada debe saltar correctamente")
    void testSaltarTurnoConDireccionCambiada() {
        control3Jugadores.cambiarDireccion(); // Dirección ahora -1
        
        // Con dirección -1, saltar debería ir al índice anterior: 0 -> 2
        control3Jugadores.saltarTurno();
        assertEquals(2, control3Jugadores.getIndiceActual());
        
        control3Jugadores.saltarTurno();
        assertEquals(1, control3Jugadores.getIndiceActual());
    }
    
    @Test
    @DisplayName("saltarTurno - debe ser equivalente a avanzar")
    void testSaltarTurnoEsEquivalenteAAvanzar() {
        ControlTurnos controlAvanzar = new ControlTurnos(3);
        ControlTurnos controlSaltar = new ControlTurnos(3);
        
        controlAvanzar.avanzar();
        controlAvanzar.avanzar();
        
        controlSaltar.saltarTurno();
        controlSaltar.saltarTurno();
        
        assertEquals(controlAvanzar.getIndiceActual(), controlSaltar.getIndiceActual());
    }
    
    //PRUEBAS DE OBTENER SIGUIENTE ÍNDICE
    
    @Test
    @DisplayName("obtenerSiguienteIndice - debe calcular el siguiente índice correctamente")
    void testObtenerSiguienteIndice() {
        // Para 3 jugadores, dirección 1
        assertEquals(1, control3Jugadores.obtenerSiguienteIndice());
        
        control3Jugadores.avanzar(); // Ahora índice 1
        assertEquals(2, control3Jugadores.obtenerSiguienteIndice());
        
        control3Jugadores.avanzar(); // Ahora índice 2
        assertEquals(0, control3Jugadores.obtenerSiguienteIndice());
    }
    
    @Test
    @DisplayName("obtenerSiguienteIndice - con dirección inversa")
    void testObtenerSiguienteIndiceDireccionInversa() {
        control3Jugadores.cambiarDireccion();
        
        // Con dirección -1, desde índice 0, siguiente es 2
        assertEquals(2, control3Jugadores.obtenerSiguienteIndice());
        
        control3Jugadores.avanzar(); // Ahora índice 2
        assertEquals(1, control3Jugadores.obtenerSiguienteIndice());
        
        control3Jugadores.avanzar(); // Ahora índice 1
        assertEquals(0, control3Jugadores.obtenerSiguienteIndice());
    }
    
    @Test
    @DisplayName("obtenerSiguienteIndice - no debe modificar el índice actual")
    void testObtenerSiguienteIndiceNoModificaActual() {
        int indiceActual = control3Jugadores.getIndiceActual();
        int siguiente = control3Jugadores.obtenerSiguienteIndice();
        
        assertEquals(indiceActual, control3Jugadores.getIndiceActual());
        assertEquals(1, siguiente);
        
        // El índice actual sigue siendo 0
        assertEquals(0, control3Jugadores.getIndiceActual());
    }
    
    //PRUEBAS DE CASOS LÍMITE
    
    @Test
    @DisplayName("Secuencia completa de juego con cambios de dirección")
    void testSecuenciaCompletaJuego() {
        // Simulación: 4 jugadores (0,1,2,3)
        ControlTurnos control = new ControlTurnos(4);
        
        // Secuencia: 0 -> 1 -> 2 -> cambiar dirección -> 1 -> 0 -> cambiar dirección -> 1 -> 2
        int[] esperados = {1, 2, 3, 2, 1, 0, 1, 2};
        
        for (int i = 0; i < esperados.length; i++) {
            if (i == 3) {
                control.cambiarDireccion(); // Cambiar después de llegar al final
            }
            if (i == 6) {
                control.cambiarDireccion(); // Cambiar nuevamente
            }
            control.avanzar();
            assertEquals(esperados[i], control.getIndiceActual(), "Error en paso " + i);
        }
    }
    
    @Test
    @DisplayName("Múltiples cambios de dirección en secuencia")
    void testMultiplesCambiosDireccion() {
        ControlTurnos control = new ControlTurnos(5);
        
        // Secuencia de índices esperados con cambios de dirección
        // Empezamos en 0
        control.avanzar(); // 1
        assertEquals(1, control.getIndiceActual());
        
        control.cambiarDireccion(); // Dirección = -1
        control.avanzar(); // 1 -> 0
        assertEquals(0, control.getIndiceActual());
        
        control.cambiarDireccion(); // Dirección = 1
        control.avanzar(); // 0 -> 1
        assertEquals(1, control.getIndiceActual());
        
        control.cambiarDireccion(); // Dirección = -1
        control.avanzar(); // 1 -> 0
        assertEquals(0, control.getIndiceActual());
        
        control.cambiarDireccion(); // Dirección = 1
        control.avanzar(); // 0 -> 1
        assertEquals(1, control.getIndiceActual());
    }
    
    @Test
    @DisplayName("avanzar con totalJugadores = 0 no debería pasar (aunque no debería ocurrir)")
    void testConstructorConCeroJugadores() {
        // Esto podría causar división por cero, pero asumimos que no se usará
        ControlTurnos control = new ControlTurnos(1);
        assertEquals(0, control.getIndiceActual());
        // La clase debería manejar correctamente el caso de 1 jugador
    }
    
    @Test
    @DisplayName("Verificar que los índices siempre están en rango")
    void testIndicesSiempreEnRango() {
        // Avanzar muchas veces para asegurar que nunca salga del rango
        for (int i = 0; i < 100; i++) {
            control3Jugadores.avanzar();
            int indice = control3Jugadores.getIndiceActual();
            assertTrue(indice >= 0 && indice < 3, 
                "Índice fuera de rango: " + indice);
        }
        
        // Con cambios de dirección
        for (int i = 0; i < 100; i++) {
            if (i % 10 == 0) {
                control4Jugadores.cambiarDireccion();
            }
            control4Jugadores.avanzar();
            int indice = control4Jugadores.getIndiceActual();
            assertTrue(indice >= 0 && indice < 4,
                "Índice fuera de rango: " + indice);
        }
    }
}