package uno;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

@DisplayName("Pruebas de la clase Main")
public class MainTest {
    
    @Test
    @DisplayName("Verificar que la clase Main existe y puede instanciarse")
    void testMainInstanciacion() {
        Main aplicacion = new Main();
        assertNotNull(aplicacion, "La clase Main debería poder instanciarse sin problemas.");
    }
}