package uno;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import uno.Carta.Tipo;

@DisplayName("Pruebas de la clase Carta")
public class CartaTest {
    
    private Carta cartaNumero;
    private Carta cartaReversa;
    private Carta cartaSalto;
    private Carta cartaRoba2;
    private Carta cartaRoba4;
    private Carta cartaComodin;
    
    @BeforeEach
    void setUp() {
        // Cartas de tipo número
        cartaNumero = new Carta("Rojo", 5);
        
        // Cartas especiales
        cartaReversa = new Carta("Azul", Tipo.REVERSA);
        cartaSalto = new Carta("Verde", Tipo.SALTO);
        cartaRoba2 = new Carta("Amarillo", Tipo.ROBA2);
        cartaRoba4 = new Carta("Verde", Tipo.ROBA4);
        cartaComodin = new Carta("Rojo", Tipo.COMODIN);
    }
   
    
    //PRUEBAS DEL CONSTRUCTOR
    
    @Test
    @DisplayName("Constructor con número - debe crear carta NUMERO correctamente")
    void testConstructorConNumero() {
        assertEquals("Rojo", cartaNumero.getColor());
        assertEquals(5, cartaNumero.getNumero());
        assertEquals(Tipo.NUMERO, cartaNumero.getTipo());
        assertTrue(cartaNumero.isVisible());
    }
    
    @Test
    @DisplayName("Constructor con tipo especial - carta debe mantener su color y tipo")
    void testConstructorConTipo() {
        assertEquals("Azul", cartaReversa.getColor());
        assertEquals(Tipo.REVERSA, cartaReversa.getTipo());
        assertEquals(-1, cartaReversa.getNumero());
        
        assertEquals("Verde", cartaSalto.getColor());
        assertEquals(Tipo.SALTO, cartaSalto.getTipo());
        
        assertEquals("Amarillo", cartaRoba2.getColor());
        assertEquals(Tipo.ROBA2, cartaRoba2.getTipo());
        
        assertEquals("Verde", cartaRoba4.getColor());
        assertEquals(Tipo.ROBA4, cartaRoba4.getTipo());
        
        assertEquals("Rojo", cartaComodin.getColor());
        assertEquals(Tipo.COMODIN, cartaComodin.getTipo());
    }
    
    //PRUEBAS DE GETTERS
    
    @Test
    @DisplayName("getColor - debe retornar el color correcto")
    void testGetColor() {
        assertEquals("Rojo", cartaNumero.getColor());
        assertEquals("Azul", cartaReversa.getColor());
        assertEquals("Verde", cartaRoba4.getColor());
        assertEquals("Rojo", cartaComodin.getColor());
    }
    
    @Test
    @DisplayName("getTipo - debe retornar el tipo correcto")
    void testGetTipo() {
        assertEquals(Tipo.NUMERO, cartaNumero.getTipo());
        assertEquals(Tipo.REVERSA, cartaReversa.getTipo());
        assertEquals(Tipo.ROBA4, cartaRoba4.getTipo());
        assertEquals(Tipo.COMODIN, cartaComodin.getTipo());
    }
    
    @Test
    @DisplayName("getNumero - cartas número retornan su valor, especiales -1")
    void testGetNumero() {
        assertEquals(5, cartaNumero.getNumero());
        assertEquals(-1, cartaReversa.getNumero());
        assertEquals(-1, cartaSalto.getNumero());
        assertEquals(-1, cartaRoba2.getNumero());
        assertEquals(-1, cartaRoba4.getNumero());
        assertEquals(-1, cartaComodin.getNumero());
    }
    
    @Test
    @DisplayName("isVisible - nueva carta debe ser visible por defecto")
    void testIsVisible() {
        assertTrue(cartaNumero.isVisible());
        assertTrue(cartaReversa.isVisible());
        assertTrue(cartaComodin.isVisible());
    }
    
    //PRUEBAS DE SETTERS
    
    @Test
    @DisplayName("setColor - debe cambiar el color de cualquier carta")
    void testSetColor() {
        cartaNumero.setColor("Verde");
        assertEquals("Verde", cartaNumero.getColor());
        
        cartaReversa.setColor("Morado");
        assertEquals("Morado", cartaReversa.getColor());
        
        cartaRoba4.setColor("Negro");
        assertEquals("Negro", cartaRoba4.getColor());
        
        cartaComodin.setColor("Azul");
        assertEquals("Azul", cartaComodin.getColor());
    }
    
    @Test
    @DisplayName("setVisible - debe cambiar la visibilidad de la carta")
    void testSetVisible() {
        cartaNumero.setVisible(false);
        assertFalse(cartaNumero.isVisible());
        
        cartaNumero.setVisible(true);
        assertTrue(cartaNumero.isVisible());
        
        cartaComodin.setVisible(false);
        assertFalse(cartaComodin.isVisible());
    }
    
    //PRUEBAS DE ES_VALIDA
    
    @Test
    @DisplayName("esValida - mismo color es válido")
    void testEsValidaMismoColor() {
        Carta otraRoja = new Carta("Rojo", 7);
        assertTrue(cartaNumero.esValida(otraRoja));
        
        Carta otraAzulReversa = new Carta("Azul", Tipo.SALTO);
        assertTrue(cartaReversa.esValida(otraAzulReversa));
    }
    
    @Test
    @DisplayName("esValida - mismo número en cartas número es válido")
    void testEsValidaMismoNumero() {
        Carta otraCarta5 = new Carta("Verde", 5);
        assertTrue(cartaNumero.esValida(otraCarta5));
    }
    
    @Test
    @DisplayName("esValida - mismo tipo especial es válido")
    void testEsValidaMismoTipo() {
        Carta otraReversa = new Carta("Rojo", Tipo.REVERSA);
        assertTrue(cartaReversa.esValida(otraReversa));
        
        Carta otraSalto = new Carta("Amarillo", Tipo.SALTO);
        assertTrue(cartaSalto.esValida(otraSalto));
    }
    
    @Test
    @DisplayName("esValida - comodín siempre es válido")
    void testEsValidaComodin() {
        Carta cualquierCarta = new Carta("Negro", 0);
        assertTrue(cartaComodin.esValida(cualquierCarta));
        assertTrue(cartaComodin.esValida(cartaNumero));
        assertTrue(cartaComodin.esValida(cartaReversa));
    }
    
    @Test
    @DisplayName("esValida - ROBA4 siempre es válido")
    void testEsValidaRoba4() {
        Carta cualquierCarta = new Carta("Azul", 3);
        assertTrue(cartaRoba4.esValida(cualquierCarta));
        assertTrue(cartaRoba4.esValida(cartaNumero));
    }
    
    @Test
    @DisplayName("esValida - diferentes color y número debe ser inválido")
    void testEsValidaInvalido() {
        Carta cartaVerde7 = new Carta("Verde", 7);
        assertFalse(cartaNumero.esValida(cartaVerde7));
    }
    
    @Test
    @DisplayName("esValida - número con tipo diferente (mismo color) debe ser válido")
    void testEsValidaNumeroConTipoDiferenteMismoColor() {
        // Carta número ROJO 5 vs Carta REVERSA ROJO -> mismo color, debe ser válido
        Carta reversaRoja = new Carta("Rojo", Tipo.REVERSA);
        assertTrue(cartaNumero.esValida(reversaRoja));
    }
    
    @Test
    @DisplayName("esValida - número con tipo diferente y color diferente debe ser inválido")
    void testEsValidaNumeroConTipoDiferenteColorDiferente() {
        // Carta número ROJO 5 vs Carta REVERSA AZUL -> diferente color y tipo, debe ser inválido
        Carta reversaAzul = new Carta("Azul", Tipo.REVERSA);
        assertFalse(cartaNumero.esValida(reversaAzul));
    }
    
    //PRUEBAS DE TOSTRING
    
    @Test
    @DisplayName("toString - carta número debe mostrar 'color número'")
    void testToStringCartaNumero() {
        assertEquals("Rojo 5", cartaNumero.toString());
        
        Carta cartaAmarillo3 = new Carta("Amarillo", 3);
        assertEquals("Amarillo 3", cartaAmarillo3.toString());
        
        Carta cartaNegro0 = new Carta("Negro", 0);
        assertEquals("Negro 0", cartaNegro0.toString());
    }
    
    @Test
    @DisplayName("toString - carta especial debe mostrar 'color TIPO'")
    void testToStringCartaEspecial() {
        assertEquals("Azul REVERSA", cartaReversa.toString());
        assertEquals("Verde SALTO", cartaSalto.toString());
        assertEquals("Amarillo ROBA2", cartaRoba2.toString());
        assertEquals("Verde ROBA4", cartaRoba4.toString());
        assertEquals("Rojo COMODIN", cartaComodin.toString());
    }
    
    //PRUEBAS ADICIONALES
    
    @Test
    @DisplayName("Múltiples cartas número con mismo número pero diferente color")
    void testMultiplesCartasMismoNumero() {
        Carta rojo5 = new Carta("Rojo", 5);
        Carta azul5 = new Carta("Azul", 5);
        Carta verde5 = new Carta("Verde", 5);
        
        assertTrue(rojo5.esValida(azul5));
        assertTrue(rojo5.esValida(verde5));
        assertTrue(azul5.esValida(verde5));
    }
    
    @Test
    @DisplayName("Cartas especiales del mismo color pero diferentes tipos")
    void testCartasEspecialesMismoColorDiferenteTipo() {
        Carta reversaRoja = new Carta("Rojo", Tipo.REVERSA);
        Carta saltoRoja = new Carta("Rojo", Tipo.SALTO);
        
        // Mismo color, debe ser válido según la lógica actual
        assertTrue(reversaRoja.esValida(saltoRoja));
    }
    
    @Test
    @DisplayName("La visibilidad no afecta a esValida")
    void testVisibilidadNoAfectaValidez() {
        Carta cartaInvisible = new Carta("Azul", 7);
        cartaInvisible.setVisible(false);
        
        assertFalse(cartaNumero.esValida(cartaInvisible));
        assertFalse(cartaInvisible.esValida(cartaNumero));
    }
    
    @Test
    @DisplayName("Crear carta con color null")
    void testCartaConColorNull() {
        Carta cartaNull = new Carta(null, 5);
        assertNull(cartaNull.getColor());
        
        Carta cartaNullEspecial = new Carta(null, Tipo.REVERSA);
        assertNull(cartaNullEspecial.getColor());
    }
}