package uno;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Disabled;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

@DisplayName("Pruebas unitarias para la interfaz y logica del juego UNO")
public class VentanaUnoTest {

    private VentanaUno ventana;

    @BeforeEach
    public void setUp() {
        ventana = new VentanaUno();
    }

    @Test
    @DisplayName("Validar la configuracion inicial de la ventana principal")
    public void testInicializacionComponentes() {
        assertNotNull(ventana, "La instancia de la ventana no debería ser nula");
        assertEquals("Juego UNO v3 - Edición Final Gráfica con Historial", ventana.getTitle());
        assertTrue(ventana.isVisible() == false, "La ventana debería iniciar invisible");
    }

    @Test
    @DisplayName("Verificar el estado logico del boton decir UNO")
    public void testEstadoBotonUno() {
        assertFalse(ventana.isHaDichoUno(), "El estado inicial de decir Uno debe ser falso");
        ventana.resetDichoUno();
        assertFalse(ventana.isHaDichoUno());
    }

    @Test
    @DisplayName("Cargar imagen de carta desde el sistema de archivos")
    public void testCargaImagenReal() {
        Carta cartaExistente = new Carta("Azul", 5);
        ventana.actualizarMesa(cartaExistente, "Azul");
        assertNotNull(ventana.getLabelCartaMesa().getIcon(), 
            "El componente Label deberia contener un icono cargado");
    }

    @Test
    @DisplayName("Validar el valor inicial de la eleccion del jugador humano")
    public void testFlujoEleccionHumano() {
        assertEquals(-2, ventana.getEleccionUltima(), "La eleccion inicial debe ser -2");
    }

    @Test
    @DisplayName("Verificar que la interfaz no falle con una mano de cartas vacia")
    public void testActualizarManoVacia() {
        List<Carta> manoVacia = new ArrayList<>();
        List<Integer> validas = new ArrayList<>();
        assertDoesNotThrow(() -> {
            ventana.actualizarMano(manoVacia, "TestPlayer", true, validas);
        });
    }

    @Test
    @DisplayName("Validar la actualizacion visual de los paneles de los oponentes")
    public void testActualizarBots() {
        List<Jugador> jugadores = new ArrayList<>();
        jugadores.add(new JugadorHumano("Humano"));
        jugadores.add(new JugadorComputadora("Bot 1"));
        jugadores.add(new JugadorComputadora("Bot 2"));

        assertDoesNotThrow(() -> {
            ventana.actualizarBots(jugadores, 1);
        });
    }
    
    @Test
    @DisplayName("Comprobar regla de validacion con mismo color")
    public void testEsValidaMismoColor() {
    	Carta mesa = new Carta("Verde", 1);
    	Carta mano = new Carta("Verde", 7);
    	assertTrue(mano.esValida(mesa), "La carta debe ser valida por color");
    }
    
    @Test
    @DisplayName("Comprobar regla de validacion con mismo numero")
    public void testEsValidaMismoNumero() {
        Carta mesa = new Carta("Rojo", 5);
        Carta mano = new Carta("Azul", 5);
        assertTrue(mano.esValida(mesa), "La carta debee ser valida por numero");
    }
    
    @Test
    @DisplayName("Comprobar que la carta Roba 4 es siempre una jugada valida")
    public void testRoba4SiempreValido() {
        Carta mesa = new Carta("Verde", 2);
        Carta rob4 = new Carta("Negro", Carta.Tipo.ROBA4);
        assertTrue(rob4.esValida(mesa), "Roba 4 debe ser jugable sobre cualquier carta");
    }
    
    @Test
    @DisplayName("Comprobar que la carta Comodin es siempre una jugada valida")
    public void testComodinSiempreValido() {
    	Carta mesa = new Carta("Rojo", 5);
    	Carta comodin = new Carta("Negro", Carta.Tipo.COMODIN);
    	assertTrue(comodin.esValida(mesa), "El comodin debe ser jugable sobre cualquier carta");
    }
    
    @Test
    @DisplayName("Validar que la computadora seleccione un color dentro del rango permitido")
    public void testElegirColorBot() {
        JugadorComputadora bot = new JugadorComputadora("BotTest");
        String color = bot.elegirColor(new VentanaUno());
        List<String> coloresValidos = List.of("Rojo", "Azul", "Verde", "Amarillo");
        assertTrue(coloresValidos.contains(color), "El color debe pertenecer a la lista oficial");
    }
    
    @Test
    @Disabled
    @DisplayName("Validar el proceso de seleccion de color mediante la interfaz humana")
    public void testElegirColorHumano() {
        JugadorHumano humano = new JugadorHumano("TestUser");
        String colorElegido = humano.elegirColor(ventana);
        assertNotNull(colorElegido, "El color no puede ser nulo tras la seleccion");
        List<String> coloresValidos = List.of("Rojo", "Azul", "Verde", "Amarillo");
        assertTrue(coloresValidos.contains(colorElegido), "El color debe ser una opcion valida de la interfaz");
    }
}