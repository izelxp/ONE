package uno;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.DisplayName;

@DisplayName("Pruebas de la clase ReglasJuego")
public class ReglasJuegoTest {
    
    //PRUEBAS DE ES MOVIMIENTO VÁLIDO
    
    @Test
    @DisplayName("esMovimientoValido - comodín siempre es válido")
    void testEsMovimientoValidoComodin() {
        Carta comodin = new Carta("Negro", Carta.Tipo.COMODIN);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(comodin, mesa, "Rojo"));
        assertTrue(ReglasJuego.esMovimientoValido(comodin, mesa, "Azul"));
        assertTrue(ReglasJuego.esMovimientoValido(comodin, mesa, "Verde"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - ROBA4 siempre es válido")
    void testEsMovimientoValidoRoba4() {
        Carta roba4 = new Carta("Negro", Carta.Tipo.ROBA4);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(roba4, mesa, "Rojo"));
        assertTrue(ReglasJuego.esMovimientoValido(roba4, mesa, "Azul"));
        assertTrue(ReglasJuego.esMovimientoValido(roba4, mesa, "Verde"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - mismo color es válido")
    void testEsMovimientoValidoMismoColor() {
        Carta jugada = new Carta("Rojo", 7);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - mismo número es válido")
    void testEsMovimientoValidoMismoNumero() {
        Carta jugada = new Carta("Azul", 5);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - mismo tipo especial es válido")
    void testEsMovimientoValidoMismoTipo() {
        Carta jugada = new Carta("Azul", Carta.Tipo.REVERSA);
        Carta mesa = new Carta("Rojo", Carta.Tipo.REVERSA);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - número con mismo color pero número diferente es válido")
    void testEsMovimientoValidoNumeroMismoColor() {
        Carta jugada = new Carta("Rojo", 7);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - color actual diferente sin coincidencia es inválido")
    void testEsMovimientoValidoInvalido() {
        Carta jugada = new Carta("Azul", 7);
        Carta mesa = new Carta("Rojo", 5);
        
        assertFalse(ReglasJuego.esMovimientoValido(jugada, mesa, "Verde"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - número diferente sin coincidencia es inválido")
    void testEsMovimientoValidoNumeroDiferente() {
        Carta jugada = new Carta("Azul", 7);
        Carta mesa = new Carta("Rojo", 5);
        
        assertFalse(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    public static boolean esMovimientoValido(Carta jugada, Carta mesa, String colorActual) {
        // Si es comodín, siempre es válido
        if (jugada.getTipo() == Carta.Tipo.COMODIN || jugada.getTipo() == Carta.Tipo.ROBA4) {
            return true;
        }
        
        // Validar por color (solo si ambas son números o la jugada es número)
        if (jugada.getColor().equals(colorActual)) {
            // Si la jugada es número, puede jugarse sobre cualquier carta del mismo color
            if (jugada.getTipo() == Carta.Tipo.NUMERO) {
                return true;
            }
            // Si la jugada es especial, solo puede jugarse sobre especial del mismo tipo
            return jugada.getTipo() == mesa.getTipo();
        }
        
        // Validar por número (solo entre números)
        if (jugada.getTipo() == Carta.Tipo.NUMERO && mesa.getTipo() == Carta.Tipo.NUMERO) {
            return jugada.getNumero() == mesa.getNumero();
        }
        
        // Validar por tipo de acción (Salto, Reversa, etc)
        return jugada.getTipo() == mesa.getTipo();
    }
    
    @Test
    @DisplayName("esMovimientoValido - carta número contra tipo especial sin mismo color es inválido")
    void testEsMovimientoValidoNumeroContraEspecial() {
        Carta jugada = new Carta("Azul", 7);
        Carta mesa = new Carta("Rojo", Carta.Tipo.REVERSA);
        
        assertFalse(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - carta especial contra número sin mismo color es inválido")
    void testEsMovimientoValidoEspecialContraNumero() {
        Carta jugada = new Carta("Azul", Carta.Tipo.REVERSA);
        Carta mesa = new Carta("Rojo", 5);
        
        assertFalse(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - mismo color con tipo especial es válido")
    void testEsMovimientoValidoMismoColorTipoEspecial() {
        Carta jugada = new Carta("Rojo", Carta.Tipo.SALTO);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - mismo color con carta número es válido")
    void testEsMovimientoValidoMismoColorConNumero() {
        Carta jugada = new Carta("Rojo", 7);
        Carta mesa = new Carta("Rojo", Carta.Tipo.REVERSA);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    @Test
    @DisplayName("esMovimientoValido - color actual diferente pero mismo tipo es válido")
    void testEsMovimientoValidoMismoTipoColorDiferente() {
        Carta jugada = new Carta("Azul", Carta.Tipo.REVERSA);
        Carta mesa = new Carta("Rojo", Carta.Tipo.REVERSA);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Verde"));
    }
    
    //PRUEBAS DE CALCULAR PENALIZACIÓN
    
    @Test
    @DisplayName("calcularPenalizacion - carta ROBA2 devuelve 2")
    void testCalcularPenalizacionRoba2() {
        assertEquals(2, ReglasJuego.calcularPenalizacion(Carta.Tipo.ROBA2));
    }
    
    @Test
    @DisplayName("calcularPenalizacion - carta ROBA4 devuelve 4")
    void testCalcularPenalizacionRoba4() {
        assertEquals(4, ReglasJuego.calcularPenalizacion(Carta.Tipo.ROBA4));
    }
    
    @Test
    @DisplayName("calcularPenalizacion - carta NUMERO devuelve 0")
    void testCalcularPenalizacionNumero() {
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.NUMERO));
    }
    
    @Test
    @DisplayName("calcularPenalizacion - carta REVERSA devuelve 0")
    void testCalcularPenalizacionReversa() {
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.REVERSA));
    }
    
    @Test
    @DisplayName("calcularPenalizacion - carta SALTO devuelve 0")
    void testCalcularPenalizacionSalto() {
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.SALTO));
    }
    
    @Test
    @DisplayName("calcularPenalizacion - carta COMODIN devuelve 0")
    void testCalcularPenalizacionComodin() {
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.COMODIN));
    }
    
    //PRUEBAS DE CASOS LÍMITE
    
    @Test
    @DisplayName("esMovimientoValido - con colorActual null debe funcionar")
    void testEsMovimientoValidoColorActualNull() {
        Carta comodin = new Carta("Negro", Carta.Tipo.COMODIN);
        Carta mesa = new Carta("Rojo", 5);
        
        // Comodín siempre es válido incluso con colorActual null
        assertTrue(ReglasJuego.esMovimientoValido(comodin, mesa, null));
    }
    
    @Test
    @DisplayName("esMovimientoValido - misma carta (igual color y número)")
    void testEsMovimientoValidoMismaCarta() {
        Carta jugada = new Carta("Rojo", 5);
        Carta mesa = new Carta("Rojo", 5);
        
        assertTrue(ReglasJuego.esMovimientoValido(jugada, mesa, "Rojo"));
    }
    
    //PRUEBAS DE INTEGRACIÓN
    
    @Test
    @DisplayName("Integración - escenarios completos de juego")
    void testEscenariosCompletos() {
        // Escenario 1: Mesa Rojo 5, jugador juega Rojo 7 -> válido (mismo color)
        assertTrue(ReglasJuego.esMovimientoValido(
            new Carta("Rojo", 7),
            new Carta("Rojo", 5),
            "Rojo"
        ));
        
        // Escenario 2: Mesa Rojo 5, jugador juega Azul 5 -> válido (mismo número)
        assertTrue(ReglasJuego.esMovimientoValido(
            new Carta("Azul", 5),
            new Carta("Rojo", 5),
            "Rojo"
        ));
        
        // Escenario 3: Mesa Rojo 5, jugador juega Azul 7 -> inválido
        assertFalse(ReglasJuego.esMovimientoValido(
            new Carta("Azul", 7),
            new Carta("Rojo", 5),
            "Rojo"
        ));
        
        // Escenario 4: Mesa Rojo REVERSA, jugador juega Azul REVERSA -> válido (mismo tipo)
        assertTrue(ReglasJuego.esMovimientoValido(
            new Carta("Azul", Carta.Tipo.REVERSA),
            new Carta("Rojo", Carta.Tipo.REVERSA),
            "Rojo"
        ));
        
        // Escenario 5: Mesa Rojo REVERSA, jugador juega Rojo SALTO -> válido (mismo color)
        assertTrue(ReglasJuego.esMovimientoValido(
            new Carta("Rojo", Carta.Tipo.SALTO),
            new Carta("Rojo", Carta.Tipo.REVERSA),
            "Rojo"
        ));
        
        // Escenario 6: Mesa Rojo REVERSA, jugador juega Comodín -> válido
        assertTrue(ReglasJuego.esMovimientoValido(
            new Carta("Negro", Carta.Tipo.COMODIN),
            new Carta("Rojo", Carta.Tipo.REVERSA),
            "Rojo"
        ));
    }
    
    @Test
    @DisplayName("Integración - penalizaciones en secuencia")
    void testPenalizacionesSecuencia() {
        // ROBA2 da 2 cartas
        assertEquals(2, ReglasJuego.calcularPenalizacion(Carta.Tipo.ROBA2));
        
        // ROBA4 da 4 cartas
        assertEquals(4, ReglasJuego.calcularPenalizacion(Carta.Tipo.ROBA4));
        
        // Otras cartas dan 0
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.SALTO));
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.REVERSA));
        assertEquals(0, ReglasJuego.calcularPenalizacion(Carta.Tipo.NUMERO));
    }
    
    @Test
    @DisplayName("Integración - todos los tipos de cartas con mismo color")
    void testTodosLosTiposMismoColor() {
        String color = "Rojo";
        Carta mesa = new Carta(color, 5);
        
        // Probar todos los tipos de carta con el mismo color
        Carta[] cartasParaProbar = {
            new Carta(color, 3),           // Número
            new Carta(color, Carta.Tipo.REVERSA),
            new Carta(color, Carta.Tipo.SALTO),
            new Carta(color, Carta.Tipo.ROBA2)
        };
        
        for (Carta carta : cartasParaProbar) {
            assertTrue(ReglasJuego.esMovimientoValido(carta, mesa, color),
                "La carta " + carta + " debería ser válida por mismo color");
        }
    }
    
    @Test
    @DisplayName("Integración - todos los tipos de carta con mismo número")
    void testTodosLosTiposMismoNumero() {
        int numero = 7;
        Carta mesa = new Carta("Rojo", numero);
        
        // Probar cartas número del mismo número (diferente color)
        Carta mismaNumero = new Carta("Azul", numero);
        assertTrue(ReglasJuego.esMovimientoValido(mismaNumero, mesa, "Rojo"));
        
        // Cartas especiales con mismo número no existen (tienen número -1)
        Carta especial = new Carta("Azul", Carta.Tipo.REVERSA);
        assertFalse(ReglasJuego.esMovimientoValido(especial, mesa, "Rojo"));
    }
}