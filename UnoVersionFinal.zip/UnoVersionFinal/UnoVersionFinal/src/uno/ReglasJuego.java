package uno;

/**
 * Validaciones estáticas de las reglas del UNO.
 */
public class ReglasJuego {
    public static boolean esMovimientoValido(Carta jugada, Carta mesa, String colorActual) {
        if (jugada.getTipo() == Carta.Tipo.COMODIN || jugada.getTipo() == Carta.Tipo.ROBA4) return true;
        if (jugada.getColor().equals(colorActual)) return true;
        if (jugada.getTipo() == Carta.Tipo.NUMERO && mesa.getTipo() == Carta.Tipo.NUMERO) {
            return jugada.getNumero() == mesa.getNumero();
        }
        return jugada.getTipo() == mesa.getTipo();
    }

    public static int calcularPenalizacion(Carta.Tipo tipo) {
        if (tipo == Carta.Tipo.ROBA2) return 2;
        if (tipo == Carta.Tipo.ROBA4) return 4;
        return 0;
    }
}