package uno;

import java.util.List;
import java.util.Random;

/**
 * Lógica automatizada para los bots del juego.
 */
public class JugadorComputadora extends Jugador {

    public JugadorComputadora(String nombre) {
        super(nombre);
    }

    @Override
    public Carta ejecutarTurno(Carta cartaMesa, Mazo mazoPrincipal, VentanaUno ventana) {
        List<Integer> validas = getMano().obtenerCartasValidas(cartaMesa);
        if (validas.isEmpty()) return null; 
        return jugarCarta(validas.get(0));
    }

    @Override
    public String elegirColor(VentanaUno ventana) {
        String[] colores = {"Rojo", "Azul", "Verde", "Amarillo"};
        return colores[new Random().nextInt(colores.length)];
    }
}