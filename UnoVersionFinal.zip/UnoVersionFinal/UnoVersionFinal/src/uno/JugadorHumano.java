package uno;

import java.util.List;

/**
 * Controla la interacción mediante clics de la interfaz gráfica.
 */
public class JugadorHumano extends Jugador {

    public JugadorHumano(String nombre) {
        super(nombre);
    }

    @Override
    public Carta ejecutarTurno(Carta cartaMesa, Mazo mazoPrincipal, VentanaUno ventana) {
        List<Integer> validas = getMano().obtenerCartasValidas(cartaMesa);

        if (validas.isEmpty()) {
            ventana.mostrarMensaje("No tienes cartas válidas. Tienes que robar.");
        }

        // Bucle infinito que se detiene hasta que el jugador haga un movimiento válido
        while (true) {
            int idxElegido = ventana.pedirJugada();

            // -1 es Robar, -3 es Rendirse. Estos siempre son válidos.
            if (idxElegido == -1 || idxElegido == -3) {
                return null; 
            }

            // Si la carta que tocó está en la lista de válidas, la juega.
            if (validas.contains(idxElegido)) {
                return jugarCarta(idxElegido);
            } else {
                // Si tocó una carta inválida, mostramos el mensaje y el bucle vuelve a empezar.
                ventana.mostrarMensaje("¡Esa carta no es válida para jugarse!\nDebe coincidir en color, en número, o ser un Comodín.");
            }
        }
    }

    @Override
    public String elegirColor(VentanaUno ventana) {
        return ventana.pedirColor();
    }
}