package uno;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.io.File;
import java.util.List;

/**
 * Interfaz gráfica principal del juego estilo Brisca (Norte, Sur, Este, Oeste).
 * Incluye mejoras en la visibilidad del nombre del jugador y el color de la mesa.
 */
public class VentanaUno extends JFrame {
    private JPanel panelMesa, panelMano, panelBotNorte, panelBotOeste, panelBotEste;
    private JLabel labelCartaMesa, labelMazo;
    private JTextArea areaHistorial;
    private volatile int eleccionHumano = -2;
    private boolean haDichoUno = false;

    public VentanaUno() {
        setTitle("Juego UNO v3 - Edición Final Gráfica con Historial");
        setSize(1150, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(34, 139, 34));
        setLocationRelativeTo(null);

        // Panel Central (Mesa, Mazo e Historial)
        panelMesa = new JPanel(new BorderLayout());
        panelMesa.setOpaque(false);
        
        JPanel panelCartas = new JPanel(new GridBagLayout());
        panelCartas.setOpaque(false);
        labelCartaMesa = new JLabel();
        labelMazo = new JLabel();
        
        ImageIcon iconoMazo = cargarIcono("imagenes/carta_inicio.jpg", 130, 190);
        if (iconoMazo != null) labelMazo.setIcon(iconoMazo);
        else { labelMazo.setText("[ MAZO ]"); labelMazo.setForeground(Color.WHITE); }
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        panelCartas.add(labelMazo, gbc);
        panelCartas.add(labelCartaMesa, gbc);
        
        areaHistorial = new JTextArea(15, 45);
        areaHistorial.setEditable(false);
        areaHistorial.setBackground(new Color(20, 20, 20));
        areaHistorial.setForeground(Color.WHITE);
        areaHistorial.setFont(new Font("Monospaced", Font.BOLD, 12));
        areaHistorial.setLineWrap(true);
        areaHistorial.setWrapStyleWord(true);
        
        JScrollPane scrollLog = new JScrollPane(areaHistorial);
        scrollLog.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE), 
                "Historial de Partida", 0, 0, null, Color.WHITE));
        
        panelMesa.add(panelCartas, BorderLayout.CENTER);
        panelMesa.add(scrollLog, BorderLayout.EAST);
        add(panelMesa, BorderLayout.CENTER);

        panelMano = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
        panelMano.setBackground(new Color(50, 50, 50));
        JScrollPane scrollMano = new JScrollPane(panelMano);
        scrollMano.setPreferredSize(new Dimension(1150, 210));
        add(scrollMano, BorderLayout.SOUTH);

        panelBotNorte = crearPanelBot();
        panelBotOeste = crearPanelBot();
        panelBotEste = crearPanelBot();
        add(panelBotNorte, BorderLayout.NORTH);
        add(panelBotOeste, BorderLayout.WEST);
        add(panelBotEste, BorderLayout.EAST);
    }

    public boolean isHaDichoUno() { return haDichoUno; }
    public void resetDichoUno() { haDichoUno = false; }

    public void agregarLog(String mensaje) {
        areaHistorial.append("▶ " + mensaje + "\n");
        areaHistorial.setCaretPosition(areaHistorial.getDocument().getLength());
    }

    private JPanel crearPanelBot() {
        JPanel p = new JPanel(); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false); p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return p;
    }

    public Object[] pedirDatosIniciales() {
        JTextField txtNombre = new JTextField("Jugador 1");
        String[] opcionesBots = {"1", "2", "3"};
        JComboBox<String> cbBots = new JComboBox<>(opcionesBots);
        cbBots.setSelectedIndex(2);
        Object[] m = {"Ingresa tu nombre:", txtNombre, "Cantidad de oponentes:", cbBots};
        
        if (JOptionPane.showConfirmDialog(null, m, "Configuración UNO", JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            String n = txtNombre.getText().trim();
            if (n.isEmpty()) n = "Anónimo";
            return new Object[]{n, Integer.parseInt((String)cbBots.getSelectedItem())};
        }
        System.exit(0); return null;
    }

    public void actualizarBots(List<Jugador> jugadores, int indiceActual) {
        panelBotOeste.removeAll(); panelBotNorte.removeAll(); panelBotEste.removeAll();
        String[] imagenesBots = {"bot1.png", "bot2.png", "bot3.png"};
        int bIdx = 0;
        for (int i = 1; i < jugadores.size(); i++) {
            JPanel bUI = construirBot(jugadores.get(i), i == indiceActual, imagenesBots[bIdx++]);
            if (bIdx == 1) panelBotOeste.add(bUI);
            else if (bIdx == 2 && jugadores.size() == 4) panelBotNorte.add(bUI);
            else panelBotEste.add(bUI);
        }
        revalidate(); repaint();
    }

    private JPanel construirBot(Jugador b, boolean turno, String img) {
        JPanel p = new JPanel(new BorderLayout()); 
        p.setOpaque(false);
        
        JLabel av = new JLabel(cargarIcono("imagenes/" + img, 70, 70));
        if (av.getIcon() == null) av.setText("🤖");
        av.setHorizontalAlignment(JLabel.CENTER);
        
        JLabel n = new JLabel(b.getNombre());
        n.setForeground(turno ? Color.YELLOW : Color.WHITE);
        n.setFont(new Font("Arial", Font.BOLD, 14));
        n.setHorizontalAlignment(JLabel.CENTER); 
        
        JPanel panelCartas = new JPanel(new FlowLayout(FlowLayout.CENTER, -20, 0));
        panelCartas.setOpaque(false);
        ImageIcon reverso = cargarIcono("imagenes/carta_mesa.png", 35, 50);
        
        for(int i = 0; i < b.getMano().size(); i++) {
            JLabel lblC = new JLabel(reverso);
            panelCartas.add(lblC);
        }
        
        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.setOpaque(false);
        panelSur.add(n, BorderLayout.NORTH);
        panelSur.add(panelCartas, BorderLayout.CENTER);
        
        p.add(av, BorderLayout.CENTER); 
        p.add(panelSur, BorderLayout.SOUTH);
        return p;
    }

    /**
     * Actualiza la mesa con una fuente más grande para el color actual.
     */
    public void actualizarMesa(Carta mesa, String color) {
        ImageIcon icono = cargarIcono(mesa.getRutaImagen(), 150, 220);
        if(icono != null) { labelCartaMesa.setIcon(icono); labelCartaMesa.setText(""); }
        else { labelCartaMesa.setIcon(null); labelCartaMesa.setText(mesa.toString()); }
        
        // AJUSTE: Color y tamaño del título de la mesa aumentado
        TitledBorder bMesa = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2), " COLOR ACTUAL: " + color.toUpperCase() + " ");
        bMesa.setTitleColor(Color.CYAN);
        bMesa.setTitleFont(new Font("Arial", Font.BOLD, 22));
        panelMesa.setBorder(bMesa);
    }

    /**
     * Actualiza la mano destacando el nombre del jugador humano.
     */
    public void actualizarMano(List<Carta> mano, String nombre, boolean esTurnoHumano, List<Integer> validas) {
        panelMano.removeAll();
        
        // AJUSTE: Nombre del jugador resaltado con color amarillo y fuente grande
        TitledBorder bMano = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2), " JUGADOR: " + nombre + " ");
        bMano.setTitleColor(Color.YELLOW);
        bMano.setTitleFont(new Font("Arial", Font.BOLD, 20));
        panelMano.setBorder(bMano);
        
        for (int i = 0; i < mano.size(); i++) {
            Carta c = mano.get(i);
            JButton btn = new JButton(cargarIcono(c.getRutaImagen(), 100, 150));
            if (btn.getIcon() == null) btn.setText(c.toString());
            btn.setPreferredSize(new Dimension(105, 155));
            
            if (esTurnoHumano) {
                btn.setEnabled(true);
                final int idx = i;
                btn.addActionListener(e -> eleccionHumano = idx);
                
                if (validas != null && validas.contains(i)) {
                    btn.setBorder(BorderFactory.createLineBorder(Color.GREEN, 4));
                } else {
                    btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
                }
            } else {
                btn.setEnabled(false);
                btn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            }
            panelMano.add(btn);
        }

        if (esTurnoHumano) {
            JPanel panelAcciones = new JPanel(new GridLayout(3, 1, 5, 5));
            panelAcciones.setOpaque(false);

            JButton btnUno = new JButton("¡UNO!");
            btnUno.setPreferredSize(new Dimension(100, 50));
            if (haDichoUno) {
                btnUno.setBackground(Color.GRAY);
                btnUno.setEnabled(false);
            } else {
                btnUno.setBackground(Color.ORANGE);
                btnUno.setForeground(Color.BLACK);
                btnUno.setFont(new Font("Arial", Font.BOLD, 14));
                btnUno.addActionListener(e -> {
                    haDichoUno = true;
                    btnUno.setBackground(Color.GRAY);
                    btnUno.setEnabled(false);
                });
            }

            JButton rob = new JButton("ROBAR");
            rob.setBackground(Color.RED); rob.setForeground(Color.WHITE);
            rob.addActionListener(e -> eleccionHumano = -1);
            
            JButton ren = new JButton("RENDIRSE");
            ren.setBackground(Color.BLACK); ren.setForeground(Color.WHITE);
            ren.addActionListener(e -> {
                int conf = JOptionPane.showConfirmDialog(this, "¿Seguro que quieres rendirte?", "Confirmar", JOptionPane.YES_NO_OPTION);
                if(conf == JOptionPane.YES_OPTION) eleccionHumano = -3;
            });

            panelAcciones.add(btnUno);
            panelAcciones.add(rob);
            panelAcciones.add(ren);
            panelMano.add(panelAcciones);
        }
        revalidate(); repaint();
    }

    private ImageIcon cargarIcono(String r, int w, int h) {
        File f = new File(r); if (!f.exists()) return null;
        return new ImageIcon(new ImageIcon(r).getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH));
    }

    public int pedirJugada() { 
        eleccionHumano = -2; 
        while (eleccionHumano == -2) pausar(100); 
        return eleccionHumano; 
    }

    public int getEleccionUltima() { return eleccionHumano; }
    
    public String pedirColor() {
        String[] c = {"Rojo", "Azul", "Verde", "Amarillo"};
        int s = JOptionPane.showOptionDialog(this, "Has jugado un comodín. Elige el nuevo color:", "Cambio de Color", 
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, c, c[0]);
        return s == -1 ? "Rojo" : c[s];
    }

    public int pedirRevancha(String ganador) {
        String[] opciones = {"Jugar Revancha", "Salir del Juego"};
        return JOptionPane.showOptionDialog(this, 
                "Partida finalizada. Ganador: " + ganador + "\n¿Qué deseas hacer ahora?", 
                "Fin de la partida", 
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, 
                null, opciones, opciones[0]);
    }
    
    public void mostrarMensaje(String m) { JOptionPane.showMessageDialog(this, m); }
    private void pausar(int ms) { try { Thread.sleep(ms); } catch (Exception e) {} }
    
    /**
     * Permite a la clase de prueba acceder a la etiqueta de la mesa
     * para verificar que las imágenes se carguen correctamente.
     */
    public JLabel getLabelCartaMesa() {
        return labelCartaMesa;
    }
}