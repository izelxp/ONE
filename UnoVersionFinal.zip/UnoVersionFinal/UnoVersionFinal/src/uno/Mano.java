package uno;

import java.util.ArrayList;
import java.util.List;

/**
 * Representa la colección de cartas individuales que posee un jugador
 * en un momento determinado de la partida.
 */
public class Mano {
    private List<Carta> cartas;
    
    /**
     * Constructor que inicializa una mano vacía mediante una estructura de lista.
     */
    public Mano() { cartas = new ArrayList<>(); }
    
    /**
     * Agrega una nueva carta a la mano del jugador.
     * * @param carta Objeto Carta que se desea añadir.
     * @throws IllegalArgumentException si la carta proporcionada es nula.
     */
    public void agregarCarta(Carta carta) {
        if (carta == null) throw new IllegalArgumentException("Carta nula");
        cartas.add(carta);
    }
    
    /**
     * Remueve y devuelve una carta de la mano según su posición en el índice.
     * * @param indice Posición numérica de la carta en la mano.
     * @return El objeto Carta removido, o null si el índice está fuera de rango.
     */
    public Carta quitarCarta(int indice) {
        if (indice >= 0 && indice < cartas.size()) return cartas.remove(indice);
        return null;
    }
    
    /**
     * Analiza las cartas de la mano y devuelve las posiciones indexadas de aquellas
     * que cumplen las reglas para ser jugadas sobre la carta actual de la mesa.
     * * @param cartaMesa La carta de referencia que se encuentra actualmente en la mesa.
     * @return Una lista de enteros con los índices de las cartas válidas para tirar.
     */
    public List<Integer> obtenerCartasValidas(Carta cartaMesa) {
        List<Integer> validas = new ArrayList<>();
        for (int i = 0; i < cartas.size(); i++) {
            if (cartas.get(i).esValida(cartaMesa)) validas.add(i);
        }
        return validas;
    }
    
    /**
     * Obtiene la lista completa de cartas dentro de la mano.
     * * @return List de objetos Carta.
     */
    public List<Carta> getCartas() { return cartas; }
    
    /**
     * Verifica si la mano se ha quedado completamente sin cartas.
     * * @return true si la mano está vacía, false en caso contrario.
     */
    public boolean estaVacia() { return cartas.isEmpty(); }
    
    /**
     * Obtiene la cantidad total de cartas que tiene el jugador actualmente en su mano.
     * * @return Entero con el tamaño de la mano.
     */
    public int size() { return cartas.size(); }
}