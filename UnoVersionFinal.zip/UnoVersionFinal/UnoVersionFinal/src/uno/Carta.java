package uno;

/**
 * Representa una carta individual del juego Uno.
 * * @author Grupo 1101
 */
public class Carta {
    public enum Tipo { NUMERO, REVERSA, SALTO, ROBA2, ROBA4, COMODIN }
    
    private String color;
    private Tipo tipo;
    private int numero;
    private boolean visible;

    /**
     * Constructor para cartas numéricas normales.
     * @param color El color de la carta.
     * @param numero El número de la carta (0-9).
     */
    public Carta(String color, int numero) {
        this.color = color;
        this.numero = numero;
        this.tipo = Tipo.NUMERO;
        this.visible = true;
    }
    
    /**
     * Constructor para cartas especiales.
     * @param color El color base de la carta.
     * @param tipo El efecto especial de la carta.
     */
    public Carta(String color, Tipo tipo) {
        this.color = color;
        this.tipo = tipo;
        this.numero = -1;
        this.visible = true;
    }
    
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public Tipo getTipo(){ return tipo; }
    public int getNumero() { return numero; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean visible) { this.visible = visible; }
    
    /**
     * Genera la ruta de la imagen asegurando que los comodines usen el color Negro.
     * @return Ruta del archivo PNG.
     */
    public String getRutaImagen() {
        if (tipo == Tipo.COMODIN || tipo == Tipo.ROBA4) {
            return "imagenes/Negro_" + tipo + ".png";
        }
        if (tipo == Tipo.NUMERO) {
            return "imagenes/" + color + "_" + numero + ".png";
        } else {
            return "imagenes/" + color + "_" + tipo + ".png";
        }
    }
    
    /**
     * Verifica si esta carta se puede jugar sobre la carta de la mesa.
     * @param otra La carta en la mesa.
     * @return true si es válida.
     */
    public boolean esValida(Carta otra) {
        if (this.tipo == Tipo.COMODIN || this.tipo == Tipo.ROBA4) return true;
        if (this.color.equals(otra.color)) return true;
        if (this.tipo == Tipo.NUMERO && otra.tipo == Tipo.NUMERO) return this.numero == otra.numero;
        return this.tipo == otra.tipo;
    }
    
    @Override
    public String toString() {
        if (tipo == Tipo.NUMERO) return color + " " + numero;
        return color + " " + tipo;        
    }
}