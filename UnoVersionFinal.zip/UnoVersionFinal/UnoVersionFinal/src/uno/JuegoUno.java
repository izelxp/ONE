package uno;

import java.util.ArrayList;
import java.util.List;

/**
 * Controla el flujo principal del juego UNO, gestionando los jugadores,
 * el mazo de robo, el mazo de descarte y la ejecución de los turnos.
 */
public class JuegoUno {
    private List<Jugador> jugadores;
    private Mazo mazoPrincipal;
    private List<Carta> mazoDescarte;
    private ControlTurnos gestorTurnos;
    private String colorActual;
    private boolean juegoTerminado;
    private VentanaUno ventana;

    /**
     * Constructor que inicializa una nueva partida de UNO con un jugador humano
     * y la cantidad especificada de oponentes virtuales (bots).
     * * @param nombre El nombre del jugador humano.
     * @param bots Cantidad de jugadores computadora a añadir.
     * @param v Instancia de la interfaz gráfica del juego.
     */
    public JuegoUno(String nombre, int bots, VentanaUno v) {
        this.ventana = v;
        this.jugadores = new ArrayList<>();
        this.mazoDescarte = new ArrayList<>();
        this.mazoPrincipal = new Mazo();
        this.juegoTerminado = false;

        jugadores.add(new JugadorHumano(nombre));
        String[] nCompu = {"Tonio", "Maria", "Pedro"};
        for (int i = 0; i < bots; i++) jugadores.add(new JugadorComputadora(nCompu[i]));

        this.gestorTurnos = new ControlTurnos(jugadores.size());
        repartirCartas();
        iniciarJuego();
    }

    /**
     * Reparte de forma equitativa 7 cartas del mazo principal a cada uno
     * de los jugadores inscritos en la partida.
     */
    private void repartirCartas() {
        for (Jugador j : jugadores) {
            for (int i = 0; i < 7; i++) j.tomarCarta(mazoPrincipal);
        }
    }

    /**
     * Determina la carta inicial de la mesa asegurando que no sea un comodín,
     * establece el color de inicio y notifica el arranque en el historial visual.
     */
    private void iniciarJuego() {
        Carta inicial = mazoPrincipal.tomarCarta();
        while (inicial.getTipo() == Carta.Tipo.COMODIN || inicial.getTipo() == Carta.Tipo.ROBA4) {
            mazoPrincipal.agregarCartaAlFinal(inicial);
            inicial = mazoPrincipal.tomarCarta();
        }
        mazoDescarte.add(inicial);
        colorActual = inicial.getColor();
        ventana.agregarLog("¡PARTIDA INICIADA!");
        ventana.agregarLog("Carta inicial: " + inicial);
    }

    /**
     * Ciclo principal del juego que se ejecuta de forma continua. Gestiona 
     * interacciones de turnos, validación de jugadas, penalizaciones y condiciones de victoria.
     */
    public void jugar() {
        while (!juegoTerminado) {
            Jugador actual = jugadores.get(gestorTurnos.getIndiceActual());
            Carta mesa = mazoDescarte.get(mazoDescarte.size() - 1);
            
            ventana.actualizarBots(jugadores, gestorTurnos.getIndiceActual());
            ventana.actualizarMesa(mesa, colorActual);
            
            Carta ref = new Carta(colorActual, mesa.getTipo());
            if(mesa.getTipo() == Carta.Tipo.NUMERO) ref = mesa;

            boolean esHumano = (actual instanceof JugadorHumano);
            Jugador humano = jugadores.get(0); 
            
            List<Integer> validas = null;
            if (esHumano) validas = actual.getMano().obtenerCartasValidas(ref);
            
            ventana.actualizarMano(humano.getMano().getCartas(), humano.getNombre(), esHumano, validas);

            if (!esHumano) pausar(1200);

            Carta jugada = actual.ejecutarTurno(ref, mazoPrincipal, ventana);

            if (esHumano && ventana.getEleccionUltima() == -3) {
                ventana.agregarLog(actual.getNombre() + " se ha rendido.");
                int opcion = ventana.pedirRevancha("Nadie (Rendición)");
                if (opcion == 0) { reiniciarPartida(); continue; } 
                else { System.exit(0); }
            }

            if (jugada != null) {
                ventana.agregarLog(actual.getNombre() + " jugó " + jugada);
                mazoDescarte.add(jugada);
                colorActual = jugada.getColor();
                
                verificarReglaUno(actual);
                
                aplicarEfectos(jugada, actual);
            } else {
                ventana.agregarLog(actual.getNombre() + " robó una carta.");
                if (!mazoPrincipal.hayCartas()) mazoPrincipal.reconstruir(mazoDescarte);
                actual.tomarCarta(mazoPrincipal);
            }

            if (actual.getMano().estaVacia()) {
                ventana.actualizarMesa(mazoDescarte.get(mazoDescarte.size() - 1), colorActual);
                ventana.agregarLog("¡¡ " + actual.getNombre() + " GANÓ LA PARTIDA !!");
                int opcionElegida = ventana.pedirRevancha(actual.getNombre());
                if (opcionElegida == 0) reiniciarPartida();
                else { juegoTerminado = true; System.exit(0); }
            } else {
                if (esHumano) ventana.resetDichoUno();
                gestorTurnos.avanzar();
            }
        }
    }

    /**
     * Verifica si un jugador se ha quedado con una sola carta y aplica
     * una penalización de +2 cartas en caso de que el humano haya olvidado cantar UNO.
     * * @param actual El jugador que está ejecutando el turno actual.
     */
    private void verificarReglaUno(Jugador actual) {
        if (actual.getMano().size() == 1) {
            if (actual instanceof JugadorHumano) {
                if (ventana.isHaDichoUno()) {
                    ventana.agregarLog(actual.getNombre() + " gritó ¡UNO!");
                    ventana.mostrarMensaje("¡Bien! Gritaste UNO a tiempo.");
                } else {
                    ventana.agregarLog(actual.getNombre() + " olvidó decir UNO. +2 cartas.");
                    ventana.mostrarMensaje("¡Olvidaste gritar UNO antes de tirar tu penúltima carta!\nRecibes 2 cartas de penalización.");
                    for(int i = 0; i < 2; i++) {
                        if (!mazoPrincipal.hayCartas()) mazoPrincipal.reconstruir(mazoDescarte);
                        actual.tomarCarta(mazoPrincipal);
                    }
                    ventana.actualizarMano(actual.getMano().getCartas(), actual.getNombre(), false, null);
                }
            } else {
                ventana.agregarLog("¡" + actual.getNombre() + " dice UNO!");
            }
        }
    }

    /**
     * Limpia el estado de la mesa, reconstruye los mazos y vacía las manos
     * de los jugadores para iniciar una nueva ronda de revancha.
     */
    private void reiniciarPartida() {
        ventana.agregarLog("\n----------------------");
        ventana.agregarLog("¡REVANCHA INICIADA!");
        this.mazoPrincipal = new Mazo();
        this.mazoDescarte.clear();
        for (Jugador j : jugadores) j.getMano().getCartas().clear();
        this.gestorTurnos = new ControlTurnos(jugadores.size());
        repartirCartas();
        iniciarJuego();
    }

    /**
     * Aplica los efectos especiales de las cartas de acción como saltos,
     * cambios de sentido, penalizaciones de robo de cartas o elecciones de color.
     * * @param c La carta que acaba de ser jugada en la mesa.
     * @param a El jugador responsable de haber tirado la carta.
     */
    private void aplicarEfectos(Carta c, Jugador a) {
        int p = ReglasJuego.calcularPenalizacion(c.getTipo());
        if (p > 0) {
            Jugador v = jugadores.get(gestorTurnos.obtenerSiguienteIndice());
            ventana.mostrarMensaje("¡" + v.getNombre() + " roba " + p + " cartas!");
            ventana.agregarLog(v.getNombre() + " recibe +" + p);
            for(int i=0; i<p; i++) {
                if (!mazoPrincipal.hayCartas()) mazoPrincipal.reconstruir(mazoDescarte);
                v.tomarCarta(mazoPrincipal);
            }
            gestorTurnos.saltarTurno();
        }
        if (c.getTipo() == Carta.Tipo.SALTO) {
            ventana.agregarLog("Turno saltado.");
            gestorTurnos.saltarTurno();
        }
        else if (c.getTipo() == Carta.Tipo.REVERSA) {
            ventana.agregarLog("Sentido invertido.");
            gestorTurnos.cambiarDireccion();
            if (jugadores.size() == 2) gestorTurnos.saltarTurno();
        }
        else if (c.getTipo() == Carta.Tipo.COMODIN || c.getTipo() == Carta.Tipo.ROBA4) {
            colorActual = a.elegirColor(ventana);
            ventana.agregarLog("Color elegido: " + colorActual);
        }
    }

    /**
     * Detiene temporalmente el hilo de ejecución actual para generar un retraso
     * artificial que simula el tiempo de decisión de los oponentes virtuales.
     * * @param ms Tiempo de espera medido en milisegundos.
     */
    private void pausar(int ms) { try { Thread.sleep(ms); } catch (Exception e) {} }
}