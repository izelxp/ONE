package uno;

/**
 * Gestiona el índice de turnos y el flujo direccional del juego.
 */
public class ControlTurnos {
    private int indiceActual;
    private int direccion; // 1 o -1
    private int totalJugadores;

    /**
     * Inicializa el controlador de turnos.
     * @param totalJugadores La cantidad de participantes.
     */
    public ControlTurnos(int totalJugadores) {
        this.indiceActual = 0;
        this.direccion = 1;
        this.totalJugadores = totalJugadores;
    }

    public int getIndiceActual() { return indiceActual; }

    public void avanzar() {
        indiceActual = (indiceActual + direccion + totalJugadores) % totalJugadores;
    }

    public void cambiarDireccion() { direccion *= -1; }

    public void saltarTurno() { avanzar(); }
    
    public int obtenerSiguienteIndice() {
        return (indiceActual + direccion + totalJugadores) % totalJugadores;
    }
}