package uno;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa el mazo principal o baraja del juego, encargado de la creación,
 * barajado, distribución y reconstrucción del pozo de robo.
 */
public class Mazo {
    private List<Carta> cartas;
    
    /**
     * Constructor que crea el mazo principal, inicializa la baraja reglamentaria
     * de UNO y la mezcla aleatoriamente para el inicio del juego.
     */
    public Mazo() {
        cartas = new ArrayList<>();
        inicializar();
        barajar();
    }
    
    /**
     * Añade una carta específica al final de la estructura de la baraja.
     * * @param carta El objeto Carta que se va a ingresar.
     */
    public void agregarCartaAlFinal(Carta carta) {
        this.cartas.add(carta);
    }
    
    /**
     * Genera la baraja completa de cartas del UNO (numéricas por colores,
     * cartas de acción especiales y comodines negros).
     */
    private void inicializar() {
        String[] colores = {"Rojo", "Azul", "Verde", "Amarillo"};
        for (String color : colores) {
            cartas.add(new Carta(color, 0));
            for (int numero = 1; numero <= 9; numero++){
                cartas.add(new Carta(color, numero));
                cartas.add(new Carta(color, numero));
            }
            for (int i = 1; i <= 2; i++) {
                cartas.add(new Carta(color, Carta.Tipo.SALTO));
                cartas.add(new Carta(color, Carta.Tipo.REVERSA));
                cartas.add(new Carta(color, Carta.Tipo.ROBA2));
            }
        }  
        for (int numero = 1; numero <= 4; numero++){
            cartas.add(new Carta("Negro", Carta.Tipo.ROBA4));
            cartas.add(new Carta("Negro", Carta.Tipo.COMODIN));
        } 
    }
    
    /**
     * Mezcla aleatoriamente el orden de las cartas remanentes en el mazo principal.
     */
    public void barajar() { Collections.shuffle(cartas); }
    
    /**
     * Retira y devuelve la primera carta disponible del mazo para que un jugador pueda robarla.
     * * @return El objeto Carta del tope del mazo, o null si el mazo se encuentra vacío.
     */
    public Carta tomarCarta() {
        if (cartas.isEmpty()) return null;
        return cartas.remove(0);
    }
    
    /**
     * Comprueba si el mazo de robo todavía cuenta con cartas disponibles.
     * * @return true si quedan cartas, false si se ha agotado por completo.
     */
    public boolean hayCartas() { return !cartas.isEmpty(); }
    
    /**
     * Toma las cartas acumuladas en el mazo de descarte, restablece las propiedades
     * de color originales de los comodines, las traslada al mazo principal y las mezcla.
     * Preserva la última carta jugada intacta en la mesa.
     * * @param descarte La lista que representa el pozo acumulado de descarte de la mesa.
     * @return true si la reconstrucción fue exitosa, false si no había suficientes cartas para reciclar.
     */
    public boolean reconstruir(List<Carta> descarte) {
        if (descarte.size() <= 1) return false;
        
        Carta ultima = descarte.remove(descarte.size() - 1);
        for (Carta carta : descarte) {
            if (carta.getTipo() == Carta.Tipo.COMODIN || carta.getTipo() == Carta.Tipo.ROBA4) {
                carta.setColor("Negro");
            }
        }
        cartas.addAll(descarte);
        descarte.clear();
        descarte.add(ultima);
        barajar();
        System.out.println("LOG: Mazo reconstruido.");
        return true;
    }
}