package uno;

/**
 * Clase de arranque que inicializa la GUI y el juego.
 */
public class Main {
    public static void main(String[] args) {
        VentanaUno ventana = new VentanaUno();
        Object[] datos = ventana.pedirDatosIniciales();
        
        String nombre = (String) datos[0];
        int numBots = (int) datos[1];
        
        ventana.setVisible(true);
        JuegoUno juego = new JuegoUno(nombre, numBots, ventana);
        juego.jugar();
    }
}